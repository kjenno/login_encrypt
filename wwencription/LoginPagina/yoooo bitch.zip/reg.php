<!DOCTYPE html>
<html>
<head>
    <title>Registration</title>
</head>
<body>
        <center>
            <form action="regback.php" method="post" autocomplete="off">
                <input type="hidden"name="action" value="registration">
            <table>
                <h1>registration</h1>
                <tr>
                    <td>first name: </td>
                    <td><input type="FirsName
                    " name="FirstName"></td>
                </tr>
                <tr>
                    <td>last name: </td>
                    <td><input type="LastName" name="LastName"></td>
                </tr>
                <tr>
                    <td>username: </td>
                    <td><input type="username" name="username"></td>
                </tr>
                <tr>
                    <td>Email</td>
                    <td><input type="Email" name="Email"></td>
                </tr>
                <tr>
                    <td>Password:</td>
                    <td><input type="password" name="password"></td>
                </tr>
                <tr>
                    <td></td>
                    <td><input type="submit" name="submit" value="submit"></td>
                </tr>
            </tabe>
            </form>
        </center>  
</body>
</html>